
# 모바일에서 APK 만들기 (PC 없이)

아래 방법으로 GitHub Actions에서 **APK**를 자동 빌드하고, 휴대폰에서 바로 다운로드해 설치할 수 있습니다.

## 준비물
- GitHub 계정 (https://github.com)

## 단계
1. 이 프로젝트 폴더를 ZIP 상태로 보관합니다. (혹은 여기 파일을 그대로 사용)
2. 휴대폰 브라우저에서 GitHub 로그인 → **New repository** 생성 (공개/비공개 아무거나)
3. Repos의 **Add file > Upload files**로 ZIP 업로드 후 **Commit** 합니다.
4. 업로드가 끝나면, 상단의 **Actions** 탭으로 이동 → `Android CI (Build Debug APK)` 워크플로 선택 → **Run workflow** 버튼 탭

   > 첫 실행 시 약 3~8분 정도 걸릴 수 있습니다.

5. 실행이 완료되면 **Artifacts** 섹션에 **app-debug**가 보입니다. 눌러서 **`app-debug.apk`** 파일을 다운로드하세요.

## 설치
- 안드로이드 설정 > 보안에서 **알 수 없는 앱 설치 허용**을 허용하세요. (기기/OS 버전에 따라 ‘이 출처 허용’ 등으로 표시)
- 다운로드한 `app-debug.apk`를 열어서 설치

## APK 위치 (CI 기준)
- Actions 결과 페이지의 **Artifacts: app-debug**
- 내부 경로: `app/build/outputs/apk/debug/app-debug.apk`

---

문제 생기면 이슈에 남겨주세요. (권한/SDK 관련 오류가 나면 Actions 로그를 첨부해 주세요.)
