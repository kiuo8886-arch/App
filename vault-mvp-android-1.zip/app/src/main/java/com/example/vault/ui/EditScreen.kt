package com.example.vault.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

@Composable
fun EditScreen(
    vm: RecordVm,
    id: String?,
    onDone: () -> Unit
) {
    val scope = rememberCoroutineScope()
    var title by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("MIXED") }
    var phone by remember { mutableStateOf("") }
    var address by remember { mutableStateOf("") }
    var photoUri by remember { mutableStateOf<Uri?>(null) }
    var takenAt by remember { mutableStateOf<Long?>(null) }

    LaunchedEffect(id) {
        if (id != null) {
            vm.getById(id)?.let { e ->
                title = e.title
                note = e.note ?: ""
                type = e.type
                phone = e.phone ?: ""
                address = e.address ?: ""
                photoUri = e.photoUri?.let { Uri.parse(it) }
                takenAt = e.takenAt
            }
        }
    }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri -> photoUri = uri }
    )

    Scaffold(
        topBar = { TopAppBar(title = { Text(if (id==null) "새 기록" else "기록 수정") }) }
    ) { pad ->
        Column(Modifier.padding(pad).padding(16.dp)) {
            OutlinedTextField(title, { title = it }, label = { Text("제목") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(note, { note = it }, label = { Text("메모") }, modifier = Modifier.fillMaxWidth())

            Spacer(Modifier.height(8.dp))
            Row {
                FilterChip(selected = type=="PHOTO", onClick = { type="PHOTO" }, label = { Text("사진") })
                Spacer(Modifier.width(8.dp))
                FilterChip(selected = type=="PHONE", onClick = { type="PHONE" }, label = { Text("전화") })
                Spacer(Modifier.width(8.dp))
                FilterChip(selected = type=="ADDRESS", onClick = { type="ADDRESS" }, label = { Text("주소") })
                Spacer(Modifier.width(8.dp))
                FilterChip(selected = type=="MIXED", onClick = { type="MIXED" }, label = { Text("혼합") })
            }

            if (type in listOf("PHOTO","MIXED")) {
                Spacer(Modifier.height(8.dp))
                OutlinedButton(onClick = {
                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }) { Text(if (photoUri==null) "사진 선택" else "사진 다시 선택") }
            }

            if (type in listOf("PHONE","MIXED")) {
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(phone, { phone=it }, label = { Text("전화번호") }, modifier = Modifier.fillMaxWidth())
            }

            if (type in listOf("ADDRESS","MIXED")) {
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(address, { address=it }, label = { Text("주소") }, modifier = Modifier.fillMaxWidth())
            }

            Spacer(Modifier.height(16.dp))
            Row {
                Button(onClick = {
                    scope.launch {
                        vm.upsert(
                            title = title,
                            note = note.ifBlank { null },
                            type = type,
                            photoUri = photoUri?.toString(),
                            takenAt = takenAt,
                            phone = phone.ifBlank { null },
                            address = address.ifBlank { null },
                            id = id
                        )
                        onDone()
                    }
                }, enabled = title.isNotBlank()) { Text("저장") }
                Spacer(Modifier.width(12.dp))
                if (id != null) {
                    Button(onClick = {
                        scope.launch {
                            vm.getById(id)?.let { vm.delete(it) }
                            onDone()
                        }
                    }, colors = ButtonDefaults.buttonColors()) { Text("삭제") }
                }
            }
        }
    }
}
