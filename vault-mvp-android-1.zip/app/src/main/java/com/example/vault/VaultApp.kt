package com.example.vault

import android.app.Application
import com.example.vault.core.AppGraph

class VaultApp : Application() {
    override fun onCreate() {
        super.onCreate()
        AppGraph.init(this)
    }
}
