package com.example.vault.ui

import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.fragment.app.FragmentActivity

@Composable
fun LockGate(content: @Composable () -> Unit) {
    val ctx = LocalContext.current
    var unlocked by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val can = BiometricManager.from(ctx).canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
        )
        if (ctx is FragmentActivity && can == BiometricManager.BIOMETRIC_SUCCESS) {
            val prompt = BiometricPrompt(ctx, ctx.mainExecutor,
                object : BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                        unlocked = true
                    }
                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                        unlocked = true // 사용 불가 시 통과
                    }
                })
            val info = BiometricPrompt.PromptInfo.Builder()
                .setTitle("잠금 해제")
                .setSubtitle("지문/화면잠금으로 인증")
                .setAllowedAuthenticators(
                    BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL
                ).build()
            prompt.authenticate(info)
        } else {
            unlocked = true
        }
    }

    if (unlocked) content() else CircularProgressIndicator()
}
