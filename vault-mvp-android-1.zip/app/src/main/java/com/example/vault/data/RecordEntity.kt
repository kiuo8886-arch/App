package com.example.vault.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.serialization.Serializable
import java.util.UUID

@Serializable
@Entity(tableName = "records")
data class RecordEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val title: String,
    val note: String? = null,
    val type: String,              // "PHOTO","PHONE","ADDRESS","MIXED"
    val photoUri: String? = null,  // content://
    val takenAt: Long? = null,
    val phone: String? = null,
    val address: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)
