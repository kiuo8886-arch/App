package com.example.vault.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.vault.data.RecordEntity
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecordListScreen(
    vm: RecordVm,
    onAdd: () -> Unit,
    onOpen: (String) -> Unit,
    onExport: () -> Unit,
    onImport: () -> Unit
) {
    val items by vm.records.collectAsState()
    var q by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    // SAF launchers
    val openTree = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) scope.launch { vm.exportTo(LocalContext.current, uri) }
    }
    val openFile = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) scope.launch { vm.importFrom(LocalContext.current, uri) }
    }

    // react to export/import requests
    val ctx = LocalContext.current
    LaunchedEffect(Unit) {
        vm.exportRequest.collect {
            openTree.launch(null)
        }
    }
    LaunchedEffect(Unit) {
        vm.importRequest.collect {
            openFile.launch(arrayOf("*/*"))
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("개인 저장") },
                actions = {
                    IconButton(onClick = onImport) { Text("가져오기") }
                    IconButton(onClick = onExport) { Text("내보내기") }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onAdd) { Text("+") }
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            OutlinedTextField(
                value = q,
                onValueChange = { q = it; vm.keyword.value = it },
                label = { Text("검색 (제목/메모/전화/주소)") },
                modifier = Modifier.fillMaxWidth().padding(12.dp)
            )
            LazyColumn(Modifier.fillMaxSize()) {
                items(items) { r ->
                    ListItem(
                        headlineContent = { Text(r.title) },
                        supportingContent = { Text(listOfNotNull(r.phone, r.address).joinToString(" · ")) },
                        trailingContent = { Text(typeEmoji(r.type)) },
                        modifier = Modifier
                            .clickable { onOpen(r.id) }
                            .padding(horizontal = 8.dp)
                    )
                    Divider()
                }
            }
        }
    }
}

private fun typeEmoji(t:String) = when (t) {
    "PHOTO" -> "📷"
    "PHONE" -> "📞"
    "ADDRESS" -> "📍"
    else -> "🗂"
}

@Composable
private val LocalContext get() = androidx.compose.ui.platform.LocalContext.current
