package com.example.vault.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(entities = [RecordEntity::class], version = 1)
abstract class AppDb : RoomDatabase() {
    abstract fun recordDao(): RecordDao
}
