package com.example.vault.data

import kotlinx.coroutines.flow.Flow

class RecordRepo(private val dao: RecordDao) {
    fun list(): Flow<List<RecordEntity>> = dao.observeAll()
    fun search(keyword: String): Flow<List<RecordEntity>> = dao.search("%$keyword%")
    suspend fun get(id: String) = dao.getById(id)
    suspend fun save(e: RecordEntity) = dao.upsert(e.copy(updatedAt = System.currentTimeMillis()))
    suspend fun remove(e: RecordEntity) = dao.delete(e)
}
