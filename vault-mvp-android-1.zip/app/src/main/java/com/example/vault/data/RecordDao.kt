package com.example.vault.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface RecordDao {
    @Query("SELECT * FROM records ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<RecordEntity>>

    @Query("SELECT * FROM records WHERE id = :id")
    suspend fun getById(id: String): RecordEntity?

    @Query("SELECT * FROM records WHERE title LIKE :q OR note LIKE :q OR phone LIKE :q OR address LIKE :q ORDER BY updatedAt DESC")
    fun search(q: String): Flow<List<RecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(item: RecordEntity)

    @Delete
    suspend fun delete(item: RecordEntity)
}
