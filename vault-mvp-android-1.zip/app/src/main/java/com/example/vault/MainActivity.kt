package com.example.vault

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.vault.ui.EditScreen
import com.example.vault.ui.RecordListScreen
import com.example.vault.ui.LockGate
import com.example.vault.ui.theme.AppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AppTheme {
                LockGate {
                    val nav = rememberNavController()
                    val vm: com.example.vault.ui.RecordVm = viewModel()
                    NavHost(navController = nav, startDestination = "list") {
                        composable("list") {
                            RecordListScreen(
                                vm = vm,
                                onAdd = { nav.navigate("edit") },
                                onOpen = { id -> nav.navigate("edit?id=" + id) },
                                onExport = { vm.requestExport() },
                                onImport = { vm.requestImport() }
                            )
                        }
                        composable("edit?id={id}") { backStackEntry ->
                            val id = backStackEntry.arguments?.getString("id")
                            EditScreen(vm = vm, id = id, onDone = { nav.popBackStack() })
                        }
                        composable("edit") {
                            EditScreen(vm = vm, id = null, onDone = { nav.popBackStack() })
                        }
                    }
                }
            }
        }
    }
}
