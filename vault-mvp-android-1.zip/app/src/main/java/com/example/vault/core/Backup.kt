package com.example.vault.core

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import androidx.security.crypto.EncryptedFile
import androidx.security.crypto.MasterKey
import com.example.vault.data.RecordEntity
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.nio.charset.Charset

@Serializable
data class ExportBundle(val version:Int=1, val exportedAt:Long = System.currentTimeMillis(), val records: List<RecordEntity>)

object Backup {
    private val json = Json { prettyPrint = true; encodeDefaults = true }

    fun exportEncrypted(context: Context, targetUri: Uri, items: List<RecordEntity>) {
        val parent = DocumentFile.fromTreeUri(context, targetUri) ?: error("경로 권한 필요")
        val file = parent.createFile("application/octet-stream", "vault_backup.json.enc")
            ?: error("파일 생성 실패")
        val masterKey = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        val enc = EncryptedFile.Builder(context, file.uri, masterKey, EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB).build()
        val bytes = json.encodeToString(ExportBundle(records = items)).toByteArray(Charset.forName("UTF-8"))
        enc.openFileOutput().use { it.write(bytes) }
    }

    fun importEncrypted(context: Context, fileUri: Uri): List<RecordEntity> {
        val masterKey = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        val enc = EncryptedFile.Builder(context, fileUri, masterKey, EncryptedFile.FileEncryptionScheme.AES256_GCM_HKDF_4KB).build()
        val text = enc.openFileInput().use { it.readBytes().toString(Charsets.UTF_8) }
        val bundle = Json.decodeFromString<ExportBundle>(text)
        return bundle.records
    }
}
