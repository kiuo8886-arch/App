package com.example.vault.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.vault.core.AppGraph
import com.example.vault.core.Backup
import com.example.vault.data.RecordEntity
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

class RecordVm(app: Application) : AndroidViewModel(app) {
    private val repo = AppGraph.repo

    val keyword = MutableStateFlow("")
    val records = keyword
        .debounce(150)
        .flatMapLatest { if (it.isBlank()) repo.list() else repo.search(it) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    // export/import events (observed by UI)
    private val _exportRequest = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val exportRequest = _exportRequest.asSharedFlow()

    private val _importRequest = MutableSharedFlow<Unit>(extraBufferCapacity = 1)
    val importRequest = _importRequest.asSharedFlow()

    fun requestExport() { _exportRequest.tryEmit(Unit) }
    fun requestImport() { _importRequest.tryEmit(Unit) }

    fun upsert(
        title: String,
        note: String?,
        type: String,
        photoUri: String?,
        takenAt: Long?,
        phone: String?,
        address: String?,
        id: String? = null
    ) = viewModelScope.launch {
        val e = RecordEntity(
            id = id ?: UUID.randomUUID().toString(),
            title = title,
            note = note,
            type = type,
            photoUri = photoUri,
            takenAt = takenAt,
            phone = phone,
            address = address
        )
        repo.save(e)
    }

    fun delete(e: RecordEntity) = viewModelScope.launch { repo.remove(e) }

    suspend fun exportTo(context: android.content.Context, dirUri: Uri) {
        val list = records.value
        Backup.exportEncrypted(context, dirUri, list)
    }

    suspend fun importFrom(context: android.content.Context, fileUri: Uri) {
        val items = Backup.importEncrypted(context, fileUri)
        for (e in items) repo.save(e)
    }

    suspend fun getById(id: String): RecordEntity? = repo.get(id)
}
