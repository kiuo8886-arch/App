package com.example.vault.core

import android.content.Context
import androidx.room.Room
import com.example.vault.data.AppDb
import com.example.vault.data.RecordRepo

object AppGraph {
    lateinit var db: AppDb
    lateinit var repo: RecordRepo

    fun init(context: Context) {
        db = Room.databaseBuilder(context, AppDb::class.java, "vault.db").build()
        repo = RecordRepo(db.recordDao())
    }
}
